FISHING BROTHERS – VIZUALNI ASSETS

Tyto soubory jsou připravené jako náhrady za obrázky se stejnými názvy
v kořenové složce GitHub repozitáře Tadee21/Fishing-brothers-.

Nahraj a nahraď v kořeni repozitáře:
- header-scene.jpg
- pond.jpg, lake.jpg, river.jpg
- bait-boilies.jpg, bait-corn.jpg, bait-wobbler.jpg
- bait-live.jpg, bait-rubber.jpg

Názvy zachovej přesně. HTML už používá právě tyto názvy.
Obrázky jsou optimalizované pro web a mobilní zobrazení.
