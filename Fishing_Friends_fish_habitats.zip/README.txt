Fishing Friends – underwater fish image assets

Upload all 10 fish-habitat-*.webp files to the ROOT of GitHub repository Tadee21/Fishing-brothers-. Keep exact filenames.

Files: kapr, amur, stika, candat, sumec, jeseter, lin, tolstolobik, bolen, okoun.
